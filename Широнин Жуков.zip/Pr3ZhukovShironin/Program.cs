﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Pr3ZhukovShironin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char[,] alfrus = {     {'A', 'B', 'C', 'D', 'E'},
                                   {'F', 'G', 'H', 'I', 'K'},
                                   {'L', 'M', 'N', 'O', 'P'},
                                   {'Q', 'R', 'S', 'T', 'U'},
                                   {'V', 'W', 'X', 'Y', 'Z'},
            };


            Console.WriteLine("Введите сообщение Английскими буквами для шифровки: ");
            string message = Console.ReadLine();
            string new_message = "";



            for (int i = 0; i < message.Length; i++)
            {
                for (int j = 0; j < alfrus.GetLength(0); j++)
                    for (int k = 0; k < alfrus.GetLength(1); k++)
                        if (Char.ToLower(alfrus[j, k]) == message[i++] || Char.ToUpper(alfrus[j, k]) == message[i++])
                        {
                            new_message += (Convert.ToString(j) + Convert.ToString(k));
                            break;
                        }

            }
            Console.WriteLine(new_message);
            Console.ReadKey();
        }
    }
}
